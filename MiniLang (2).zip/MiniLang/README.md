# MiniLang – Multi-Language Compiler and Stack-Based Virtual Machine
(MiniLang · Python · C++ · Java)

A compiler-construction project in pure Python (no parser generators). Source programs in
**MiniLang**, a **Python subset**, a **C++ subset** or a **Java subset** are analysed by language-specific
front ends and translated into **one shared bytecode** that a hand-written stack VM executes.

```
 MiniLang ┐
 Python   │                                        ┌ Semantic → Bytecode Generator → Bytecode → VM → Output
 C++      ├→ Lexer → Parser (with error recovery) → AST ┤
 Java     ┘                                        └ (all errors collected and reported together)
```

## Run it
```bash
python main.py                          # GUI
python main.py examples/cpp/loops.cpp   # CLI (language detected from the extension)
python main.py examples/java/Hello.java --tokens --ast --bytecode
python main.py examples/python/loops.py # Python
python main.py prog.txt --lang cpp      # choose the language explicitly
python -m unittest discover -s tests -v # 101 tests
```
GUI: pick the **Language** (MiniLang / C++ / Java), write code or choose an **Example**,
then **Compile (F5)**, **Execute (F6)** or **Step (F7)**.

## Interface (baby pink · burgundy · beige)
* **Gradient header** (burgundy → rose → baby pink) with logo and language badges - the active
  language badge lights up (MiniLang = baby pink, C++ = peach, Java = lavender).
* **Animated effects:** rounded buttons that fade, lift and dip on hover/press; a glow that sweeps
  along the header; pipeline chips that light up one after another after Compile and *pulse*
  while the VM is stepping; slide-in toast messages; a flash on each new console line; window fade-in.
* **Colour-coded panels:** syntax highlighting (types, keywords, builtins, numbers, strings,
  comments), coloured token types, syntax-tree nodes and bytecode opcodes, accent strips per panel.
* Colours are defined once at the top of `minilang/widgets.py` (`BABY`, `BURGUNDY`, `BG` ...).

## It behaves like a compiler, not an interpreter
* The whole program is analysed first. **Lexical, syntax and semantic errors are all reported
  together**, sorted by position – the parser uses panic-mode recovery (inserts a missing `;`,
  skips junk to the next statement, keeps broken declarations so later uses don't cascade).
* Follow-on errors caused by an earlier lexical error are suppressed.
* **No bytecode is produced and nothing runs** unless the program has zero errors.
* The Errors tab shows the count per stage and the faulty lines are highlighted in the editor;
  the pipeline bar shows how many errors each stage found.

## Variables & Values panel
The Execution tab has a **Variables & Values** table (Variable | Value | Type). It lists every
variable of the program from the moment you compile (`— not assigned yet`), fills in each value as
the program runs, and highlights the variable that was just changed while you **Step**.
The window fits small (1366×768) screens automatically.

## Step-by-step execution
**Step** runs exactly one VM instruction. The *Execution Trace* table keeps **every** executed
step (step no., IP, instruction, stack after it) – nothing disappears. The VM panel shows the
bytecode with a pointer to the next instruction, the live stack and the variable memory.
(A `STORE` pops its value off the stack into memory – that is why a pushed value "leaves" the
stack; it is now visible in the Memory table and in the trace.) After the program halts, Step
does not silently restart: press **Reset VM** to run it again.

## Python subset
`x = 5` (no declarations, dynamic typing, one flat scope), `print(a, b, sep=, end=)`, f-strings
with format specs (`f"{x:.2f}"`), `if/elif/else`, `while`, `for i in range(a, b, step)`,
`break/continue/pass`, tuple swap `a, b = b, a`, chained/augmented assignment (`+= //= **=` ...),
`and/or/not` (return operand values like Python), chained comparisons, `+ - * / // % **`
(`/` is always float, `//` floors, `%` follows the divisor), string `*` repetition, built-ins
`str int float len abs min max round`. Type errors are **runtime** errors, as in real Python;
indentation errors, missing colons, undefined names and unclosed brackets are compile-time errors.
Not supported (clear message): `def`/`class`/`import`/`try`/`lambda`, lists, dicts, tuples, `None`, `input`.

## Languages
| | MiniLang | C++ subset | Java subset |
|---|---|---|---|
| Program | statements | `int main(){…}` (optional) | `class X { main }` (optional) |
| Variables | `let x = 1;` (inferred) | `int double bool string auto` | `int double boolean String var` |
| Output | `print(x);` | `cout << x << endl;` `to_string(x)` | `System.out.println/print` `String.valueOf(x)` |
| `7 / 2` | 3.5 | 3 (integer division) | 3 (integer division) |
| `"a" + 1` | type error | type error | `"a1"` (concatenation) |
| Float print | `5` | `5` | `5.0` |

Shared: `if / else if / else`, `while`, `break`, `continue`, `+ - * / %`, `== != < > <= >=`,
`&& || !` (short-circuit). C++/Java also: `for`, `++ -- += -= *= /= %=`, `return`, several
declarators per line, single-statement bodies, `std::` prefix, `#include`/`import` (ignored).
Not supported (reported with a clear message): user-defined functions/classes, arrays,
`do-while`, input.

## Project layout
| File | Role |
|---|---|
| `minilang/languages.py` | language definitions (keywords, operators, samples) |
| `minilang/lexer.py`, `tokens.py` | one table-driven lexer, collects all lexical errors |
| `minilang/parser.py` | MiniLang recursive-descent parser + error recovery (grammar in the docstring) |
| `minilang/cparser.py` | C++ / Java parser (reuses the recovery machinery) |
| `minilang/ast_nodes.py` | shared AST + tree printer |
| `minilang/semantic.py` | scopes, types, per-language rules, implicit conversions |
| `minilang/bytecode.py` | AST → instructions (jump back-patching, loops, short-circuit logic) |
| `minilang/vm.py` | stack, memory, IP, execution engine, execution trace |
| `minilang/compiler.py` | pipeline driver (collects all errors) |
| `minilang/gui.py` | Tkinter UI (window, tabs, handlers) |
| `minilang/widgets.py` | theme palette + animated widgets (buttons, chips, header, toast) |
| `examples/{minilang,cpp,java}/` | sample programs, incl. an `error_multiple` file per language |
| `tests/test_minilang.py` | 101 tests |

## Instruction set
`PUSH POP LOAD STORE ADD SUB MUL DIV EQ NEQ GT LT GTE LTE JMP JMP_IF_FALSE PRINT HALT`
(from the requirements) plus `NEG NOT MOD IDIV CONCAT TOSTR TOINT TOFLOAT WRITE NEWLINE`.
